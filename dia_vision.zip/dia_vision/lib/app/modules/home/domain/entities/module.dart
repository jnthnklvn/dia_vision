import 'package:dia_vision/app/shared/utils/route_enum.dart';

class Module {
  final String name;
  final String imageSrc;
  final bool svg;
  final String routeName;
  final bool needPatient;

  Module(this.name, this.imageSrc, this.svg, this.routeName, this.needPatient);
}

final alimentation = Module(
  "Alimentação",
  "assets/images/veggie-salad.svg",
  true,
  RouteEnum.alimentation.name,
  true,
);
final exercises = Module(
  "Atividade Física",
  "assets/images/exercise.png",
  false,
  RouteEnum.exercises.name,
  true,
);
final selfCare = Module(
  "Autocuidado",
  "assets/images/self-care.png",
  false,
  RouteEnum.selfCare.name,
  false,
);
final medicalCenters = Module(
  "Centros de Saúde",
  "assets/images/medical-center.png",
  false,
  RouteEnum.medicalCenters.name,
  false,
);
final glicemy = Module(
  "Glicemia",
  "assets/images/glucose-meter.svg",
  true,
  RouteEnum.glicemy.name,
  true,
);
final medications = Module(
  "Medicações",
  "assets/images/pill-bottle.png",
  false,
  RouteEnum.medications.name,
  true,
);
final feet = Module(
  "Pés",
  "assets/images/feet.png",
  false,
  RouteEnum.feet.name,
  true,
);
final doctors = Module(
  "Profissionais da Saúde",
  "assets/images/doctor.png",
  false,
  RouteEnum.doctors.name,
  true,
);
final kidney = Module(
  "Rins",
  "assets/images/kidney.png",
  false,
  RouteEnum.kidney.name,
  true,
);
final vision = Module(
  "Apps de Visão",
  "assets/images/vision.svg",
  true,
  RouteEnum.vision.name,
  false,
);

List<Module> modules = [
  alimentation,
  vision,
  exercises,
  selfCare,
  medicalCenters,
  glicemy,
  medications,
  feet,
  // doctors,
  kidney,
];
