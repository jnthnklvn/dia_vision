// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'medication_widget_controller.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$MedicationsWidgetController on _MedicationsWidgetControllerBase, Store {
  final _$medicationAtom =
      Atom(name: '_MedicationsWidgetControllerBase.medication');

  @override
  MedicationNotify get medication {
    _$medicationAtom.reportRead();
    return super.medication;
  }

  @override
  set medication(MedicationNotify value) {
    _$medicationAtom.reportWrite(value, super.medication, () {
      super.medication = value;
    });
  }

  final _$isLoadingAtom =
      Atom(name: '_MedicationsWidgetControllerBase.isLoading');

  @override
  bool get isLoading {
    _$isLoadingAtom.reportRead();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.reportWrite(value, super.isLoading, () {
      super.isLoading = value;
    });
  }

  @override
  String toString() {
    return '''
medication: ${medication},
isLoading: ${isLoading}
    ''';
  }
}
