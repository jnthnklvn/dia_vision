import 'package:dia_vision/app/shared/utils/constants.dart';
import 'package:flutter/material.dart';

// Colors
const kTextColor = Color(0xFF01215E);

// My Text Styles
const kHeadingextStyle = TextStyle(
  fontSize: 28,
  color: kTextColor,
  fontWeight: FontWeight.bold,
);
const kSubheadingextStyle = TextStyle(
  fontSize: 24,
  color: Color(0xFF61688B),
  height: 2,
);

const kTitleTextStyle = TextStyle(
  fontSize: 20,
  color: kTextColor,
  fontWeight: FontWeight.bold,
);

const kSubtitleTextSyule = TextStyle(
  fontSize: 18,
  color: kTextColor,
  // fontWeight: FontWeight.bold,
);

const kAppBarTextStyle = TextStyle(
  fontSize: 24,
  color: kPrimaryColor,
  fontWeight: FontWeight.bold,
);
