/// Descriptions
const MEDICATION_REGISTER = "Registrar medicação";
const FEET_CHECK_REGISTER = "Avaliar pés";
const SUGGEST_MEDICAL_CENTER_REGISTER = "Sugerir Centro de Saúde";
const SUGGEST_VISION_APP_REGISTER = "Sugerir App de Visão";
const EXERCISE_REGISTER = "Registrar atividade física";
const ALIMENTATION_REGISTER = "Registrar alimentação";
const SEARCH_FOOD = "Pesquisar alimento";
const ADD_FOOD = "Adicionar alimento";
const DEL_FOOD = "Remover alimento";
const ALLOW_NOTIFICATIONS = "Permitir notificações";
const DIURESIS_CHECK_REGISTER = "Avaliar diurese";
const GLICEMY_REGISTER = "Registar glicemia";
const WITHOUT_MEDICACOES_REGISTERED = "Sem medicações cadastradas";
const WITHOUT_FEET_CHECK_REGISTERED = "Sem avaliações cadastradas";
const WITHOUT_MEDICAL_CENTER_REGISTERED = "Sem centros registrados";
const WITHOUT_VISION_APP_REGISTERED = "Sem apps registrados";
const NO_FOODS_FOUND = "Não foram encontrados alimentos";
const WITHOUT_EXERCISES_REGISTERED = "Sem registros de exercício";
const WITHOUT_ALIMENTATION_REGISTERED = "Sem registros de alimentação";
const WITHOUT_DIURESIS_REGISTERED = "Sem registros de diurese";
const WITHOUT_SELF_CARE_REGISTERED = "Sem registros de autocuidado";
const WITHOUT_GLICEMY_REGISTERED = "Sem registros de glicemia";
const ASK_FORGOT_YOUR_PASSWORD = "Esqueceu sua senha? ";
const RECOVERY_PASSWORD = "Recuperar senha.";
const ASK_DOESNT_HAVE_ACCOUNT = "Não possui uma conta? ";
const ASK_HAVE_ACCOUNT = "Já possui uma conta? ";
const CLICK_SEARCH_FOOD = "Clique para pesquisar alimento";
const NOT_ENOUGH_LETTERS = "A busca deve haver pelos menos 3 letras";
const WISH_REMOVE_FOOD = "Deseja remover esse alimento da sua refeição?";
const WISH_ALLOW_NOTIFICATIONS = "Permite que sejam enviadas notificações?";
const SELECT_TYPE = "Selecione o tipo";
const REGISTRED_WITH_SUCCESS = "Registro realizado com sucesso!";
const ENABLE_NOTIFICATION_SUCCESS = "Notificação ativada com sucesso";
const DISABLE_NOTIFICATION_SUCCESS = "Notificação desativada com sucesso";
const CLEAR_SEARCH_TEXT = "Limpar texto da pesquisa";
const CLOSE_SEARCH_PAGE = "Fechar página de pesquisa";
const GLICEMY_REGISTER_TIME = "Hora de regristrar sua glicemia";
const TO_GLICEMY_REGISTER_TIME = "para o horário de glicemia";
const INTRO_PAGE_1 = "Ao utilizar este aplicativo, você pode manter os componentes como textos e botões pressionados para ouvir suas descrições... ";

// Erros
const REGISTER_NOTIFICATION_FAIL =
    "Erro ao tentar ativar notificação. Cheque se as informações sobre horário e posologia foram informadas.";
const DELETE_NOTIFICATION_FAIL =
    "Erro ao tentar desativar notificação. Tente novamente mais tarde.";

/// Words
const BACK = "voltar";
const CANCELL = "Cancelar";
const NOTIFICATION = "notificação";
const ENABLE = "ativar";
const DISABLE = "desativar";
const PASSWORD = "Senha";
const MEDICATIONS = "Medicações";
const FEET_CHECK = "Avaliações dos pés";
const MEDICAL_CENTERS = "Centros de Saúde";
const VISION_APPS = "Apps de Visão";
const EXERCISES = "Atividade Fisíca";
const ALIMENTATION = "Alimentação";
const KIDNEY_DIURESIS = "Rins e diurese";
const SELF_CARE_TITLE = "Autocuidado";
const MEDICAL_CENTER_TITLE = "Centro de Saúde";
const VISION_APP_TITLE = "App de Visão";
const GLICEMY = "Glicemia";
const REGISTER_YOUR = "Registre-se.";
const REGISTRY = "Registro";
const GO_IN = "Entre.";
const SHARE = "Compartilhar";
const CHANGE = "Alterar";
const CATEGORY = "Categoria";
const TYPE = "Tipo";
const ADD = "Adicionar";
const SUGGEST = "Sugerir";
const SEARCH = "Pesquisar";
const MODULE = "Módulo";
const SETTINGS = "Configurações";

/// Buttons
const BUTTON = "Botão";

/// Rotas
const REGISTER = "registrar";
const SELF_CARE_ARTICLE_ROUTE = "selfCareArticle";

// Parse API
const kParseApplicationId = "FttDmXSJOobmNEK2XcMp2vKF1eoWYTcmuErxWpYN";
const kParseClientKey = "K40BB2NkduZF2e2wDSLef3XbvfvLPWJHbfrkgXI8";
const kParseBaseUrl = "https://parseapi.back4app.com/";
