package com.example.dia_vision

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
