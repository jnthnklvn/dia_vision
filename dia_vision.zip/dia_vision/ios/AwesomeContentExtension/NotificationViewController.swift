//
//  NotificationViewController.swift
//  AwesomeContentExtension
//
//  Created by Jonathan Kelvin de Jesus Santos 2 on 17/05/21.
//

import awesome_notifications

@available(iOS 10.0, *)
class NotificationViewController: AwesomeContentExtension {

}
